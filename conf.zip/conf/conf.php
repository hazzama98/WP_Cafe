<?php
mysql_connect("localhost","hazzama_ads","Hazzama123");
mysql_select_db("hazzama_ads");
?>