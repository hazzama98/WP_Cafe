<?
session_start();
include"conf/conf.php";
if(empty ($_SESSION['username']) and empty ($_SESSION['password'])){
echo"<script type=\"text/javascript\">alert(\"anda tidak bisa mengakses halaman ini\");window.location=\"index.php\"</script>";
}else{
?>
<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="msapplication-tap-highlight" content="no">
  <meta name="description" content="Materialize is a Material Design Admin Template,It's modern, responsive and based on Material Design by Google. ">
  <meta name="keywords" content="materialize, admin template, dashboard template, flat admin template, responsive admin template,">
  <title>Hasil WP | SPK Pemilihan Cafe Terbaik Kota Banjarbaru</title>

  <!-- Favicons-->
  <link rel="icon" href="images/favicon/favicon-32x32.png" sizes="32x32">
  <!-- Favicons-->
  <link rel="apple-touch-icon-precomposed" href="images/favicon/apple-touch-icon-152x152.png">
  <!-- For iPhone -->
  <meta name="msapplication-TileColor" content="#00bcd4">
  <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
  <!-- For Windows Phone -->


  <!-- CORE CSS-->
  
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection">
  <!-- Custome CSS-->    
  <link href="css/custom/custom-style.css" type="text/css" rel="stylesheet" media="screen,projection">
  
  


  <!-- INCLUDED PLUGIN CSS ON THIS PAGE -->
  <link href="js/plugins/prism/prism.css" type="text/css" rel="stylesheet" media="screen,projection">
  <link href="js/plugins/perfect-scrollbar/perfect-scrollbar.css" type="text/css" rel="stylesheet" media="screen,projection">
  <link href="js/plugins/data-tables/css/jquery.dataTables.min.css" type="text/css" rel="stylesheet" media="screen,projection">
  <link href="js/plugins/chartist-js/chartist.min.css" type="text/css" rel="stylesheet" media="screen,projection">
</head>

<body>
  <!-- Start Page Loading -->
  <div id="loader-wrapper">
      <div id="loader"></div>        
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
  </div>
  <!-- End Page Loading -->

  <!-- //////////////////////////////////////////////////////////////////////////// -->

  <!-- START HEADER -->
  <header id="header" class="page-topbar">
        <!-- start header nav-->
        <div class="navbar-fixed">
            <nav class="navbar-color">
                <div class="nav-wrapper">
                    <ul class="left">                      
                      <li><h1 class="logo-wrapper"><a href="home.php" class="brand-logo darken-1">SPK</a> <span class="logo-text">Materialize</span></h1></li>
                    </ul>
                    <ul class="right hide-on-med-and-down">
                        <li><a href="javascript:void(0);" class="waves-effect waves-block waves-light toggle-fullscreen"><i class="mdi-action-settings-overscan"></i></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- end header nav-->
  </header>
  <!-- END HEADER -->

  <!-- //////////////////////////////////////////////////////////////////////////// -->

  <!-- START MAIN -->
  <div id="main">
    <!-- START WRAPPER -->
    <div class="wrapper">

      <!-- START LEFT SIDEBAR NAV-->
      <aside id="left-sidebar-nav">
        <ul id="slide-out" class="side-nav fixed leftside-navigation">
            <li class="user-details cyan darken-2">
            <div class="row">
                <div class="col col s4 m4 l4">
                    <img src="http://www.myiconfinder.com/uploads/iconsets/256-256-ac7256a56da1fa7c09a699ddec407e7e-human.png" alt="" class="circle responsive-img valign profile-image">
                </div>
                <div class="col col s8 m8 l8">
                    <ul id="profile-dropdown" class="dropdown-content">
                        <li><a href="logout.php"><i class="mdi-hardware-keyboard-tab"></i> Logout</a>
                        </li>
                    </ul>
                    <a class="btn-flat dropdown-button waves-effect waves-light white-text profile-btn" href="#" data-activates="profile-dropdown">ITBAARTS<i class="mdi-navigation-arrow-drop-down right"></i></a>
                    <p class="user-roal">Administrator</p>
                </div>
            </div>
            </li>
            <li class="bold"><a href="home.php" class="waves-effect waves-cyan"><i class="mdi-action-dashboard"></i> Dashboard</a>
            </li>
            <li class="bold"><a href="create-nilai.php" class="waves-effect waves-cyan"><i class="mdi-action-note-add"></i> Tambah Data</a>
            </li>
            <li class="bold"><a href="saw.php" class="waves-effect waves-cyan"><i class="mdi-action-print"></i> Hasil SAW</a>
            </li>
            <li class="bold"><a href="wp.php" class="waves-effect waves-cyan"><i class="mdi-action-print"></i> Hasil WP</a>
            </li>
        </ul>
        <a href="#" data-activates="slide-out" class="sidebar-collapse btn-floating btn-medium waves-effect waves-light hide-on-large-only cyan"><i class="mdi-navigation-menu"></i></a>
        </aside>
      <!-- END LEFT SIDEBAR NAV-->

      <!-- //////////////////////////////////////////////////////////////////////////// -->

      <!-- START CONTENT -->
      <section id="content">




                <!-- Form Rangking -->
<div id="basic-form" class="section">
              <div class="row">
                <div class="col s12 m12 l12">
                  <div class="card-panel">
            <div id="table-datatables">
              <center><h4 class="header">Tabel Bobot Awal</h4></center>
            <div class="divider"></div>
            <div class="row">
                <div class="col s12 m12 l12">
                  <table id="data-table-simple" class="responsive-table display" cellspacing="0">
                    <thead>
                        <tr>
                            <th>C1</th>
                            <th>C2</th>
                            <th>C3</th>
                            <th>C4</th>
                            <th>C5</th>
                        </tr>
                    </thead>
                    <tbody>
<?
$c= array (18,28,17,16,21);
$jum = array_sum($c);
list($bobo1,$bobo2,$bobo3,$bobo4,$bobo5)=$c;
echo
"<tr><td>".$bobo1."%</td><td>".$bobo2."%</td><td>".$bobo3."%</td><td>".$bobo4."%</td><td colspan='5'>".$bobo5."%</td>"
?>
   </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
    </div>       
    </div>
    </div>

                <!-- Form Rangking -->
<div id="basic-form" class="section">
              <div class="row">
                <div class="col s12 m12 l12">
                  <div class="card-panel">
            <div id="table-datatables">
              <center><h4 class="header">Tabel Bobot Baru</h4></center>
            <div class="divider"></div>
            <div class="row">
                <div class="col s12 m12 l12">
                  <table id="data-table-simple" class="responsive-table display" cellspacing="0">
                    <thead>
                        <tr>
                            <th>C1</th>
                            <th>C2</th>
                            <th>C3</th>
                            <th>C4</th>
                            <th>C5</th>
                        </tr>
                    </thead>
                    <tbody>

<?
//bobot baru
echo"<tr><td>".round($bobo1/$jum,2)."</td><td>".round($bobo2/$jum,2)."</td><td>".round($bobo3/$jum,2)."</td><td>".round($bobo4/$jum,2)."</td><td colspan='5'>".round($bobo5/$jum,2)."</td>
</tr>";
//matrik awal
$kri=mysql_query("select *from tbl_kriteria order by id_kriteria");
?>
   </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
    </div>       
    </div>
    </div>

                <!-- Form Matrix Awal-->
<div id="basic-form" class="section">
              <div class="row">
                <div class="col s12 m12 l12">
                  <div class="card-panel">
            <div id="table-datatables">
              <center><h4 class="header">Table Matrix Awal</h4></center>
            <div class="divider"></div>
            <div class="row">
                <div class="col s12 m12 l12">
                  <table id="data-table-simple" class="responsive-table display" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID Cafe</th>
                            <th>Nama Cafe</th>
                            <th>Menu & Harga</th>
                            <th>Lokasi</th>
                            <th>Fitur</th>
                            <th>Pelayanan</th>
                            <th>Penyajian</th>
                        </tr>
                    </thead>
                    <tbody>

<?$no=1;
$nr=mysql_query("select* from tbl_normalisasi");
while($nor=mysql_fetch_array($nr)){
echo"<tr><td>".$nor['id_karyawan']."</td><td>".$nor['nama_karyawan']."</td><td>".$nor['nilai1']."</td><td>".$nor['nilai2']."</td><td>".$nor['nilai3']."</td><td>".$nor['nilai4']."</td><td colspan='2'>".$nor['nilai5']."</td></tr>";
$no++;
}
//cari max dari nilai kriteria
$Nmax=mysql_query("select max(nilai1) as max1,
							max(nilai2) as max2,
							max(nilai3) as max3,
							max(nilai4) as max4,
							max(nilai5) as max5 from tbl_normalisasi");
$max=mysql_fetch_array($Nmax);
//normalisasi
?>
                      </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
    </div>       
    </div>
    </div>


                <!-- Form Normalisasi -->
<div id="basic-form" class="section">
              <div class="row">
                <div class="col s12 m12 l12">
                  <div class="card-panel">
            <div id="table-datatables">
              <center><h4 class="header">Table Normalisasi</h4></center>
            <div class="divider"></div>
            <div class="row">
                <div class="col s12 m12 l12">
                  <table id="data-table-simple" class="responsive-table display" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID Cafe</th>
                            <th>Nama Cafe</th>
                            <th>Menu & Harga</th>
                            <th>Lokasi</th>
                            <th>Fitur</th>
                            <th>Pelayanan</th>
                            <th>Penyajian</th>
                        </tr>
                    </thead>
                    <tbody>
<?
$bobot1=$bobo1/$jum;
$bobot2=$bobo2/$jum;
$bobot3=$bobo3/$jum;
$bobot4=$bobo4/$jum;
$bobot5=$bobo5/$jum;
$no=1;
$nr=mysql_query("select* from tbl_normalisasi");
while($nor=mysql_fetch_array($nr)){
$norm1= pow ($nor['nilai1'],$bobot1);
$norm2= pow ($nor['nilai2'],$bobot2);
$norm3= pow ($nor['nilai3'],$bobot3);
$norm4= pow ($nor['nilai4'],$bobot4);
$norm5= pow ($nor['nilai5'],$bobot5);

$hnorm1=$norm1*$norm2*$norm3*$norm4*$norm5;

echo"<tr><td>".$nor['id_karyawan']."</td><td>".$nor['nama_karyawan']."</td><td>".round($norm1,2)."</td><td>".round($norm2,2)."</td><td>".round($norm3,2)."</td><td>".round($norm4,2)."</td><td>".round($norm5,2)."</td>.<td>".round($hnorm1,2)."</td></tr>";
$no++;
}
//perangkingan
?>
                      </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
    </div>       
    </div>
    </div>

                <!-- Form Rangking -->
<div id="basic-form" class="section">
              <div class="row">
                <div class="col s12 m12 l12">
                  <div class="card-panel">
            <div id="table-datatables">
              <center><h4 class="header">Tabel Peringkat</h4></center>
            <div class="divider"></div>
            <div class="row">
                <div class="col s12 m12 l12">
                  <table id="data-table-simple" class="responsive-table display" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID Cafe</th>
                            <th>Nama Cafe</th>
                            <th>Nilai</th>
                        </tr>
                    </thead>
                    <tbody>

<?$no=1;
$nr=mysql_query("select* from tbl_normalisasi");
$sql3 = mysql_query("SELECT id_karyawan,nama_karyawan,
POWER(nilai1, $bobot1) AS nilai1,
POWER(nilai2, $bobot2) AS nilai1,
POWER(nilai3, $bobot3) AS nilai1,
POWER(nilai4, $bobot4) AS nilai1,
POWER(nilai5, $bobot5) AS nilai1,
(
POWER(nilai1, $bobot1) *
POWER(nilai2, $bobot2) *
POWER(nilai3, $bobot3) *
POWER(nilai4, $bobot4) *
POWER(nilai5, $bobot5) 
) AS TOTAL,
SUM(
POWER(nilai1, $bobot1) *
POWER(nilai2, $bobot2) *
POWER(nilai3, $bobot3) *
POWER(nilai4, $bobot4) *
POWER(nilai5, $bobot5) 
)AS GRANDTOTAL
FROM tbl_normalisasi");
$q = mysql_fetch_array($sql3);
while($nor=mysql_fetch_array($nr)){


echo"<tr><td>".$nor['id_karyawan']."</td><td>".$nor['nama_karyawan']."</td><td colspan='6'>"
.round(((pow($nor['nilai1'],$bobot1))*
(pow($nor['nilai2'],$bobot2))*
(pow($nor['nilai3'],$bobot3))*
(pow($nor['nilai4'],$bobot4))*
(pow($nor['nilai5'],$bobot5)/$q['GRANDTOTAL'])
),2)
."</td></tr>";
$no++;
}
?>

                      </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
    </div>       
    </div>
    </div>

 <!-- //////////////////////////////////////////////////////////////////////////// -->

  <!-- START FOOTER -->
  <footer class="page-footer">
    <div class="footer-copyright">
      <div class="container">
        <span>Copyright © 2019 <a class="grey-text text-lighten-4" href="http://saw-azzam.banua.xyz/home.php" target="_blank">ItbaArts</a> All rights reserved.</span>
        <span class="right"> Design and Developed by <a class="grey-text text-lighten-4" href="http://geekslabs.com/">GeeksLabs</a></span>
        </div>
    </div>
  </footer>
    <!-- END FOOTER -->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/bootstrap.min.js"></script>
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="js/jquery-2.1.1.min.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="js/bootstrap.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/jquery.bxslider.min.js"></script>
  <script type="text/javascript" src="js/fliplightbox.min.js"></script>
  <script src="js/functions.js"></script>
  <script type="text/javascript">
    $('.portfolio').flipLightBox()
  </script>


    <!-- ================================================
    Scripts
    ================================================ -->
    
    <!-- jQuery Library -->
    <script type="text/javascript" src="js/plugins/jquery-1.11.2.min.js"></script>    
    <!--materialize js-->
    <script type="text/javascript" src="js/materialize.js"></script>
    <!--prism-->
    <script type="text/javascript" src="js/plugins/prism/prism.js"></script>
    <!--scrollbar-->
    <script type="text/javascript" src="js/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- data-tables -->
    <script type="text/javascript" src="js/plugins/data-tables/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/data-tables/data-tables-script.js"></script>
    <!-- chartist -->
    <script type="text/javascript" src="js/plugins/chartist-js/chartist.min.js"></script>   
    
    <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="js/plugins.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="js/custom-script.js"></script>
    <script type="text/javascript">
        /*Show entries on click hide*/
        $(document).ready(function(){
            $(".dropdown-content.select-dropdown li").on( "click", function() {
                var that = this;
                setTimeout(function(){
                if($(that).parent().hasClass('active')){
                        $(that).parent().removeClass('active');
                        $(that).parent().hide();
                }
                },100);
            });
        });
    </script>
</body>

</html><?
}
?>
