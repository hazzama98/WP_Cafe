<?php
$thn=date('Y');
$date=date('mY');
echo str_shuffle($date);
?>